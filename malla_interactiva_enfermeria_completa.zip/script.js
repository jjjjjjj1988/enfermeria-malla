
const relaciones = {
  "Razonamiento lógico matemático": ["estadísticas para ciencias de la salud"],
  "Química": ["bioquímica"],
  "Biologia Celular": ["microbiología y parasitología clínica"],
  "Bases Disciplinarias para el cuidado de enfermería": ["bases de enfermería en aps", "fundamentos del proceso de enfermería"],
  "Bioquimica": ["farmacología"],
  "Fundamentos anatómicos para el cuidado": ["fisiología", "fundamentos del proceso de enfermería"],
  "Bases de enfermería en aps": ["farmacología", "proceso de enfermería"],
  "estadísticas para ciencias de la salud": ["fundamentos en salud publica"],
  "fisiología": ["bases fisiopatologías para el cuidado"],
  "farmacología": ["proceso de enfermería"],
  "fundamentos del proceso de enfermería": ["proceso de enfermería", "gestión del cuidado en salud mental"],
  "fundamentos en salud publica": ["metodología de la investigación"],
  "gestión del cuidado en salud mental": ["gestión del cuidado en la familia en aps"],
  "proceso de enfermería": ["GDC en Adulto y Adulto Mayor Hospitalizado Medico"],
  "ingles básico 1": ["ingles básico 2"],
  "gestion en salud": ["gestión del cuidado"],
  "gestion del cuidado en adulto mayor": ["GDC en Adulto y Adulto Mayor en APS"],
  "gestión del cuidado en la familia en aps": ["GDC en Adulto y Adulto Mayor en APS"],
  "GDC en Adulto y Adulto Mayor Hospitalizado Medico": ["Fundamentos del Cuidado en Urgencias y Desastres", "Fundamentos del Cuidado en Niño y Adolescente Hospitalizado"],
  "gestión del cuidado": ["gestión de calidad y seguridad"],
  "GDC en Adulto y Adulto Mayor en APS": ["Gestión del Cuidado en Niño y Adolescente en APS"],
  "metodologia de la investigación": ["seminario de investigación"],
  "Fundamentos del Cuidado en Niño y Adolescente Hospitalizado": ["Gestión del Cuidado en Niño y Adolescente Hospitalizado"],
  "Gestión del Cuidado en Niño y Adolescente en aps": ["Promoción de la Salud en Organizaciones Comunitarias"],
  "Fundamentos del Cuidado en Urgencias y Desastres": ["GDC en Urgencias y Desastres"]
};

const malla = [
  // Todos los ramos mencionados (sin repetir)
  ...new Set(Object.keys(relaciones).concat(...Object.values(relaciones).flat()))
];

const contenedor = document.getElementById("malla");
const estado = {};

malla.forEach(nombre => {
  const div = document.createElement("div");
  div.className = "ramo";
  div.textContent = nombre;
  div.dataset.nombre = nombre;
  estado[nombre] = { aprobado: false, element: div };

  if (Object.values(relaciones).flat().includes(nombre)) {
    div.classList.add("locked");
  }

  div.onclick = () => aprobar(nombre);
  contenedor.appendChild(div);
});

function aprobar(nombre) {
  const ramo = estado[nombre];
  if (ramo.aprobado || ramo.element.classList.contains("locked")) return;

  ramo.aprobado = true;
  ramo.element.classList.add("approved");
  ramo.element.classList.remove("locked");

  // Desbloquear siguientes
  Object.entries(relaciones).forEach(([pre, posts]) => {
    if (nombre === pre) {
      posts.forEach(post => {
        const desbloquear = estado[post];
        if (desbloquear && !desbloquear.aprobado) {
          const requisitos = Object.entries(relaciones)
            .filter(([, v]) => v.includes(post))
            .map(([k]) => estado[k].aprobado);

          if (requisitos.every(Boolean)) {
            desbloquear.element.classList.remove("locked");
          }
        }
      });
    }
  });
}
